﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{

    public int speed;
    public int jumpSpeed;
    public Text countText;
    public Text winText;
    public Material mat;
    public Transform stage;
    
    private int count;
    private const float maxHeight = 2;

	// Use this for initialization
	void Start ()
    {
        count = 0;
        SetCountText();
        winText.text = "";
	}

    private void Update()
    {

    }

    private Color RandomColor()
    {
        return new Color(Random.Range(0, 256), Random.Range(0, 256), Random.Range(0, 256));
    }

    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        //rb.AddForce(new Vector3(moveHorizontal, 0, moveVertical) * speed);
        stage.Rotate(moveVertical * speed * Time.deltaTime, 0, moveHorizontal * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count++;
            SetCountText();
            mat.color = RandomColor();
        }
    }

    private void SetCountText()
    {
        countText.text = "Count: " + count.ToString();
        if (count >= 12)
            winText.text = "You Win!";
    }
}
